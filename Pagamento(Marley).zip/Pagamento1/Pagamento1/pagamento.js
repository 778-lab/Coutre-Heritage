// Gerar QR Code e redirecionar
function gerarQRCode() {
    alert("QR Code gerado!"); 
    window.location.href = "https://seusite.com/pix"; 
}

// Redireciona para a página da marca Balenciaga
function redirecionarBalenciaga() {
    window.location.href = "https://www.balenciaga.com/en-ie"; 
}

// Redireciona para a categoria Moda
function redirecionarModa() {
    window.location.href = "https://seusite.com/moda"; 
}

// Redireciona para a categoria Calçados
function redirecionarCalcados() {
    window.location.href = "https://www.balenciaga.com/en-ie"; 
}

// Selecionar outra forma de pagamento
function escolherOutraForma() {
    window.location.href = "https://www.balenciaga.com/en-ie"; 
}
